<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link href="css/style.css" rel="stylesheet">
    		<link href="css/Homelayout.css" rel="stylesheet">
    		<link type="text/css" rel="stylesheet" href="css/loginstyle.css" />
	</head>

  	<footer> 
		<div class ="footer">
			<div id="footerwrapper">
			  <div id="footerstripe"><div id="footercap"></div></div>
			  
			  <div id="footercontent">
			    <div align="center"><p>No 5-1, Block D,Jalan GC7,Glomac Cyberjaya,Jalan Teknokrat 3,63200,Cyberjaya</p><p>Tel:03-4568921 / Fax:03-7569821</p></div>
			    <div id="footernav" align="center" class="footer_Nav"><a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="AboutUs.php">About Us</a>&nbsp;&nbsp;|<a href="ContactUs.php"> Contact Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;
			    	<br>Xplore Malaysia &nbsp;&nbsp;
			    	<br><a href="http://admin.xploremalaysia.asia/" style="font-size:x-small;">Admin Site</a>&nbsp;&nbsp;
			    </div>
			  </div>
			</div>
		</div>
	</footer>
</html>
