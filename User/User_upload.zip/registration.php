<?php
$connection = mysql_connect('localhost', 'xplorema_user', 'FYPchamp1!');

if (!$connection){

    die("Database Connection Failed" . mysql_error());

}
// $select_db = mysql_select_db('xplorema_FYP');
$select_db = mysql_select_db('xplorema_FYP');

if (!$select_db){

    die("Database Selection Failed" . mysql_error());

}

// If the values are posted, insert them into the database.
    if (isset($_POST['username']) && isset($_POST['password'])){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $ic=$_POST['ic'];
        $password = $_POST['password'];
        $phone= $_POST['phone'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $code = $_POST['code'];
        $gender = $_POST['gender'];
  
        // $query = "INSERT INTO `customer` (customer_username, customer_password, gender, customer_name, customer_ic, customer_email, customer_phone, customer_address) VALUES ('$username', '$password', '$gender', '$username', '$ic', '$phone', '$email', '$address, $city, $state, $code')";
        
        $data_username= "SELECT * FROM customer WHERE customer_username='$username'";
        $data_u = mysql_query($data_username);
        $values = mysql_fetch_array($data_u);
        $data_email= "SELECT * FROM customer WHERE customer_email='$email'";
        $data_e = mysql_query($data_email);
        $values2 = mysql_fetch_array($data_e);
        $data_ic= "SELECT * FROM customer WHERE customer_ic='$ic'";
        $data_i = mysql_query($data_ic);
        $values3 = mysql_fetch_array($data_i);

        // var_dump($values);
        // var_dump($values2);
        // var_dump($values3);

        if(empty($values) && empty($values2) && empty($values3)){

            $query = "INSERT INTO `customer` (customer_username, customer_password, gender, customer_name, customer_ic, customer_email, customer_phone, customer_address, status) VALUES ('$username', '$password', '$gender', '$username', '$ic', '$email', '$phone', '$address, $city, $state, $code','1')";
            mysql_query($query);
            $msg_success=" Register Success";
        }
        if(!empty($values))
        {
            $msg1=" Username Used";
        }
        if(!empty($values2))
        {
            $msg2=" Email Used";
        }
        if(!empty($values3))
        {
            $msg3=" IC Used";
        }

    }


?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/Homelayout.css" rel="stylesheet">
    <link href="css/Validator.min.css" rel="stylesheet">

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.leanModal.min.js"></script>
    <script type="text/javascript" src="js/Validator.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
          $('#header').load('layout/header.php');
          $('#footer').load('layout/footer.php');
        });
    </script>

    <style type="text/css">
        
        .title{
           text-transform: uppercase;
            font-family: 'Trebuchet MS', cursive;
            font-size: 30px;
            line-height: 30px;
            font-weight: 800;
            color: #4caeb8;
            margin: 0;
            padding: 16px 0 10px;
           text-align: left;
           margin-left: 12%;
           text-align: left;
           margin-left: 12%;
        }

        .hr4 {
              margin-left: 10%;
              margin-right: 10%;
              background-color: #5cb5be;
              height: 1px;
        }
        /*--------------form------------*/
        .formstyle{
            text-align: left;
            margin-left: 20%;
            
            font-size: 16px;
            font-family: "Arial Rounded MT Bold", "Helvetica Rounded", Arial, sans-serif;
            background:#ffffff;
            margin:0 auto; 
            padding-left:250px; 
            padding-top:20px;
            text-align: left;
        }
         legend{
          border: #509FA6;
         }
      
        .button {
            display:inline-block;
            width:150px;
            text-align:center;
            text-decoration:none;
            background-color: #5cb4be;
            color:#ffffff;
            padding:10px;
            font-weight: 700;
            letter-spacing:1px;
            border:0px solid #5cb4be;
            margin-top: 50px;
            margin-right: 50px;
            margin-left: 200px;

       }
        .button:hover {
           
            background: #ffffff;
            color: #5cb4be;
      }

      .buttoncancel {
            display:inline-block;
            width:150px;
            text-align:center;
            text-decoration:none;
            background-color: #ED6347;
            color:#ffffff;
            padding:10px;
            font-weight: 700;
            letter-spacing:1px;
            margin:10px;
            border:0px solid #ED6347;
            cursor: pointer;
       }
        .buttoncancel:hover {
           
            background: #ffffff;
            color: #ED6347;
      } 
        }
    </style>
  </head>

  <body>
  <div id="header"></div>

<h1 class="title">Registration Form </h1>
<hr class="hr4">

<div  class="formstyle">
<form id="registrationForm" style="margin-bottom: 0px !important;" class="form-horizontal" method="post" action="registration.php">
   
    <fieldset>
        <?php if(!empty($msg1)) {?>
         <div class="alert alert-danger col-md-10" role="alert">
            <strong>Sorry,</strong>the username has been used!
        </div>
         <?php } ?>

         <?php if(!empty($msg2)) {?>
        <div class="alert alert-danger col-md-10" role="alert">
            <strong>Sorry,</strong>the email has been used!
        </div>
         <?php } ?>

         <?php if(!empty($msg3)) {?>
        <div class="alert alert-danger col-md-10" role="alert">
            <strong>Sorry,</strong>the IC has been used!
        </div>
         <?php } ?>

         <?php if(!empty($msg_success)) {?>
        <div class="alert alert-success col-md-10" role="alert">
            <strong>Congratulation!</strong> You had successfully registered.
        </div>
         <?php } ?>

    

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>Username :</label> 
        </div>
        <div class="col-md-5">
            <input class="form-control" id="username" type="text" name="username" size="30" required="" autofocus>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>IC : </label>
        </div> 
        <div class="col-md-5">    
            <input class="form-control" id="ic" type="text" name="ic" size="30">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>Gender :</label>
        </div>
        <div class="col-md-5"> 
            <label  class="radio-inline">
              <input type="radio" name="gender" value="Male">Male
            </label>
            <label  class="radio-inline">
              <input type="radio" name="gender" value="Female">Female
            </label>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>Password :</label>
        </div>
        <div class="col-md-5">
            <input class="form-control" type="password" name="password" id="password" size="30" required="">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>E-mail :</label>
        </div>
        <div class="col-md-5">
            <input class="form-control" type="email" name="email" id="email" size="40" align="right" required="">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>Mobile :</label>
        </div>
        <div class="col-md-5">  
            <input class="form-control" type="text" name="phone" id="phone" align="right"  required="">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>Address:</label>
        </div>
        <div class="col-md-5">
            <input  class="form-control" type="text" size="62" name="address" id="address" required="">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">
            <label>State:</label>
        </div>
        <div class="col-md-5">
            <select class="form-control" name="state" id="state">
                <option value="Kuala Lumpur">Kuala Lumpur</option>
                <option value="Perlis">Perlis</option>
                <option value="Kelantan">Kelantan</option>
                <option value="Terengganu">Terengganu</option>
                <option value="Kedah">Kedah</option>
                <option value="Penang">Penang</option>
                <option value="Pahang">Pahang</option>
                <option value="Selangor">Selangor</option>
                <option value="Perak">Perak</option>
                <option value="Malacca">Malacca</option>
                <option value="Negeri Sembilan">Negeri Sembilan</option>
                <option value="Johor">Johor</option>
                <option value="Sabah">Sabah</option>
                <option value="Sarawak">Sarawak</option>
            </select>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">        
            <label>City:</label>
        </div>
        <div class="col-md-5">
            <input class="form-control" type="text" size="30" name="city" id="city" required="">
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-3 control-label">        
            <label>Zipcode:</label>
        </div>
        <div class="col-md-5">
            <input class="form-control" ype="text" size="30" name="code" id="code" required="">
        </div>
    </div>
    </fieldset>
      
        <button class="button" data-dismiss="modal" type="submit">Signup</button>
        <input class="buttoncancel" type="button" value="Reset" name="cancelbtn" onClick="window.location.reload()">
      
</form>
</div>
<script>
$(document).ready(function() {
    $('#registrationForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            username: {
                message: 'The username is not valid',
                validators: {
                    notEmpty: {
                        message: 'The username is required and cannot be empty'
                    },
                    stringLength: {
                        min: 6,
                        max: 30,
                        message: 'The username must be more than 6 and less than 30 characters long'
                    },
                    regexp: {
                        regexp: /^[a-zA-Z0-9]+$/,
                        message: 'The username can only consist of alphabetical and number'
                    },
                    different: {
                        field: 'password',
                        message: 'The username and password cannot be the same as each other'
                    }
                }
            },ic: {
                validators: {
                    notEmpty: {
                        message: 'The IC is required and cannot be empty'
                    },
                    stringLength: {
                        min: 12,
                        message: 'The IC must be at least 12 characters'
                    }
                }
            },
            password: {
                validators: {
                    notEmpty: {
                        message: 'The password is required and cannot be empty'
                    },
                    different: {
                        field: 'username',
                        message: 'The password cannot be the same as username'
                    },
                    stringLength: {
                        min: 8,
                        message: 'The password must have at least 8 characters'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'The email address is required and cannot be empty'
                    },
                    emailAddress: {
                        message: 'The email address is not a valid'
                    }
                }
            }
        }
    });
});
</script>
<div id="footer"></div>
</body>
</html>