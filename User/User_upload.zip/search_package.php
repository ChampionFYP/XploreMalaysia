<?php
session_start();
   var_dump($_SESSION['user_package_id']);

?>